'use strict';

angular.module('charts')
    .controller('HighChartAreaController', function ($scope,$http) {
      init();
    	function init() {
        serverCall();
      }
    function serverCall() {
        $http.get('/api/highchartarea')
          .success(function(data) {
            console.log('coming to the controller:', data);
            $scope.charts = {};
            $scope.charts = data;

            console.log('value of chart data :', $scope.charts);
            callChart2();
          })
          .error(function(data) {
            console.log('Error: ' + data);
          });
      }

    function callChart2() {
      var year = [];
      var anandarko = [];
      var appalachia = [];
      var bakken = [];
      var eagleford = [];
      var haynesville = [];
      var niobrara = [];
      var permian = [];
      $scope.charts.forEach(function(value,key) {
        console.log('value of value :', value);
        year.push(value.years);
        anandarko.push(value.anandarko);
        appalachia.push(value.appalachia);
        bakken.push(value.bakken);
        eagleford.push(value.eagleford);
        haynesville.push(value.haynesville);
        niobrara.push(value.niobrara);
        permian.push(value.permian);
       });
       console.log('year: ', year);
       console.log('anandarko: ', anandarko);
       Highcharts.chart('chart', {
     chart: {
         type: 'area'
     },
     title: {
         text: 'US Crude Petroleum Production by Location'
     },
     subtitle: {
         text: 'Source: EIA'
     },
     xAxis: {
         categories: years,
         tickmarkPlacement: 'on',
         title: {
             enabled: false
         }
     },
     yAxis: {
         title: {
             text: 'bbl'
         },
         labels: {
             formatter: function () {
                 // return this.value / 1000;
                 return this.value / 1000;
             }
         }
     },
     tooltip: {
         split: true,
         valueSuffix: ' bbl'
     },
     plotOptions: {
         area: {
             stacking: 'normal',
             lineColor: '#666666',
             lineWidth: 1,
             marker: {
                 lineWidth: 1,
                 lineColor: '#666666'
             }
         }
     },
     series: [{
         name: 'Anandarko',
         data: anandarko
     }, {
         name: 'Appalachia',
         data: appalachia
     }, {
         name: 'Bakken',
         data: bakken
     }, {
         name: 'Eagle Ford',
         data: eagleford
     }, {
         name: 'Haynesville',
         data: haynesville
     }, {
         name: 'niobrara',
         data: niobrara
     }, {
         name: 'Permian',
         data: permian
     }]
 });

    }


  })

    ;
