'use strict';

angular.module('charts')
    .controller('NavbarController', function ($scope, $location, $state) {
       
        $scope.$state = $state;

     
    });
