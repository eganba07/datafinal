'use strict';

angular.module('charts')
    .controller('HighChartController', function ($scope,$http) {
      init();
    	function init() {
        serverCall();
      }
    function serverCall() {
        $http.get('/api/highchartcolumn')
          .success(function(data) {
            console.log('coming to the controller:', data);
            $scope.charts = {};
            $scope.charts = data;

            console.log('value of chart data :', $scope.charts);
            callChart();
          })
          .error(function(data) {
            console.log('Error: ' + data);
          });
      }

    function callChart() {
      var state = [];
      var total = [];
      $scope.charts.forEach(function(value,key) {
        console.log('value of value :', value);
        state.push(value.state);
        total.push(value.total);
       });
       console.log('state: ', state);
       console.log('total: ', total);
       Highcharts.chart('container', {
            chart: {
                type: 'column'
            },
            series: [{
            name: 'States',
            data: gas
            }],
            title: {
                text: 'Natural Gas Production by State'
            },
            xAxis: {
              categories: state
            },
            yAxis: {
                title: {
                    text: 'MMBtu'
                }
            }
        });

    }


    });
